beamer-inf-ufrgs
================

LaTeX/Beamer theme for the Institute of Informatics at UFRGS. 

For usage, see the source of the example presentation.



